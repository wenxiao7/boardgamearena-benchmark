BoardGameArena test-mini dataset
45 subsets across five games, three task types, and three reasoning types.

JSONL fields:
instruction: task and role instructions
input: question and answer options
output: answer letter (A-E)

metadata.json maps question IDs and subset rows to game, task_type, and reasoning_type.
The question text is preserved from the source data, including any literal \n sequences.
