BoardGameArena public dataset
900 questions; 45 subsets; 20 questions per subset.

JSONL fields:
instruction: task and role instructions
input: question and answer options
output: answer letter (A-E)

metadata.json maps question IDs and subset rows to game, task_type, and reasoning_type.
The question text is preserved from the source data, including any literal \n sequences.
